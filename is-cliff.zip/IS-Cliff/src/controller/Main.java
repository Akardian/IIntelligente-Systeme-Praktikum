package controller;

import environment.World;
import environment.WorldToSmall;

public class Main {

	public static void main(String[] args) {
		World world;
		try {
			world = new World(5,4);
			world.print();
			
			do {
			
				//Agent entscheidet
				//Welt bewegt agent				
				
			} while(false);
		} catch (WorldToSmall e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
