package environment;

import java.util.Arrays;

import javax.swing.text.Position;

public class World {

	private Tile[][] world;

	private int positionX;
	private int positionY;

	private double forward = 0.8;
	private double right = 0.1;
	private double left = 0.1;
	private double down = 0.0;
	
	private final int achseX;
	private final int achseY;
	
	public World(int width, int height) throws WorldToSmall {
		if (width >= 2 && height >= 1) {
			this.achseX = width;
			this.achseY = height;

			createWorld();
		} else {
			throw new WorldToSmall("ERROR: World to small");
		}
	}

	private void createWorld() {
		world = new Tile[achseX][achseY];

		world[0][achseY - 1] = new Tile(0, achseY - 1, TileType.START);
		world[achseX - 1][achseY - 1] = new Tile(achseX - 1, achseY - 1, TileType.END);

		for (int i = 1; i < achseX - 1; i++) {
			world[i][achseY - 1] = new Tile(i, achseY - 1, TileType.CLIFF);
		}

		for (int i = 0; i < achseX; i++) {
			for (int j = 0; j < achseY - 1; j++) {
				world[i][j] = new Tile(i, j, TileType.EMPTY);
			}
		}

		positionX = 0;
		positionY = achseY - 1;
	}

	public void print() {
		for (int i = 0; i < achseY; i++) {
			for (int j = 0; j < achseX; j++) {
				if (i == positionY && j == positionX) {
					world[j][i].printf();
				} else {
					world[j][i].print();
				}
			}
			System.out.println();
		}
	}
	
	public void move(int x, int y) {
		
	}

	@Override
	public String toString() {
		return "World [world=" + Arrays.toString(world) + ", width=" + achseX + ", height=" + achseY + "]";
	}
}
