package environment;

public class WorldToSmall extends Exception {

	public WorldToSmall() {
		// TODO Auto-generated constructor stub
	}

	public WorldToSmall(String message) {
		super(message);
	}
}
