package environment;

public enum TileType {
	EMPTY, START, END, CLIFF
}
